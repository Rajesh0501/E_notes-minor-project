package com.example.Enotes_springboot_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnotesSpringbootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
