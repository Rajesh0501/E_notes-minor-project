package com.example.Enotes_springboot_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnotesSpringbootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnotesSpringbootProjectApplication.class, args);
	}

}
